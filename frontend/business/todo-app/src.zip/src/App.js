import React, { Component } from 'react';
import './App.css';
import './bootstrap.css';
import LoginComponent from "./components/restaurant/LoginComponent.jsx";
import RestaurantApp from './components/restaurant/RestaurantApp';
import CustomerSide from './components/customer/customerSide/CustomerSide'
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom'
import { Link } from 'react-router-dom';

class App extends Component {
  render() {
    return (

      <div className = "App">
        <Router>
          <div>
            <Link className="nav-link" to='/customer'>Customer</Link>
            <Link className="nav-link" to="/business">Business</Link>
              <Switch>
                  <Route path="/business"  component={RestaurantApp}/>
                  <Route path="/customer"  component={CustomerSide}/>
              </Switch>
            </div>
        </Router>


       </div>
    );
  }
}


export default App;