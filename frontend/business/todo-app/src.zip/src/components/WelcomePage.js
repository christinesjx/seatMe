import React from 'react'



const WelcomePage = () => {


    console.log("welcome page")

    return(
    <Router>
        <div>
          <Link className="nav-link" to='/'>Customer</Link>
          <Link className="nav-link" to="/business">Business</Link>
            <Switch>
                <Route path="/business" exact component={RestaurantApp}/>
                <Route path="/" exact component={CustomerSide}/>
            </Switch>
          </div>
      </Router>
    )
}

export default WelcomePage